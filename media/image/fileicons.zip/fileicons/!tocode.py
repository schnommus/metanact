import os

fullstring = ''
index = 0
for filename in os.listdir(os.getcwd()):
    if filename[-4:] == '.png':
        index += 1
        fullstring += '"' + filename[:-4] + '", '

print fullstring
